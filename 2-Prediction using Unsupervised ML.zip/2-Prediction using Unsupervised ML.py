
# coding: utf-8

# # Prediction using Unsupervised ML
# 
# ## BY AGBOOLA QUAM
# 
# **This notebook will walk through some of the basics of K-Means Clustering.**

# In[1]:


# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import sklearn.cluster as cluster
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
get_ipython().run_line_magic('matplotlib', 'inline')


# In[44]:


# Load the iris dataset
iris=pd.read_csv('iris.csv')
iris.head(8)


# In[3]:


#1 Checking the dimension of the iris dataframe
iris.shape


# In[4]:


#2 Checking the data structure and also if there is missing value in any row in the data frame
iris.info()


# In[5]:


#missing data
total = iris.isnull().sum().sort_values(ascending=False)
percent = (iris.isnull().sum()/iris.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
missing_data


# In[6]:


iris.columns.tolist()


# In[7]:


#Checking unique values in each of our variable in the dataset
iris.nunique()


# In[8]:


iris.Species.unique()


# ### DESCRIPTIVE STATISTICS

# In[9]:


iris.describe()


# In[10]:


#Checking number of passengers that survived and didn't survive in the titanic dataset
pd.DataFrame(iris.Species.value_counts())


# In[11]:


sns.pairplot(iris[['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']]);


# ## How do you find the optimum number of clusters for K Means? How does one determine the value of K?

# In[12]:


# Finding the optimum number of clusters for k-means classification

x = iris.iloc[:, [0, 1, 2, 3]].values

from sklearn.cluster import KMeans
wcss = []

for i in range(1, 11):
    kmeans = KMeans(n_clusters = i, init = 'k-means++', 
                    max_iter = 300, n_init = 10, random_state = 0)
    kmeans.fit(x)
    wcss.append(kmeans.inertia_)
    
# Plotting the results onto a line graph, 
# `allowing us to observe 'The elbow'
plt.plot(range(1, 11), wcss)
plt.title('The elbow method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS') # Within cluster sum of squares
plt.show()


# **The elbow method' from the above graph, the optimum clusters is where the elbow occurs. This is when the within cluster sum of squares (WCSS) doesn't decrease significantly with every iteration.**
# 
# **In the plot above the elbow is k=3 indicating the optimal k for this dataset is 3.**
# - As expected, the plot looks like an arm with a clear elbow at k=3

# In[64]:


kmeans=cluster.KMeans(n_clusters=3,init="k-means++")


# In[65]:


iris.iloc[:,[1]].head()


# In[67]:


iris_ind = iris.iloc[:,:4]


# In[68]:


iris_ind.head()


# In[69]:


#TARGET VARIABLE
iris_targ=iris["Species"]
iris_targ.head()


# In[70]:


type(iris_targ)


# In[71]:


# Applying kmeans to the dataset / Creating the kmeans classifier
kmeans = KMeans(n_clusters = 3, init = 'k-means++',
                max_iter = 300, n_init = 10, random_state = 0)


# In[93]:


kmeans.fit(x)


# In[94]:


y_kmeans = kmeans.fit_predict(x)


# In[95]:


y_kmeans


# In[96]:


k=kmeans.cluster_centers_
k


# In[97]:


#Confusion matrix
labels=kmeans.labels_


# In[98]:


centroids=kmeans.cluster_centers_


# In[102]:


pd.crosstab(iris_targ,labels)


# ### Let's visualize the results by plotting the data colored by these labels. We will also plot the cluster centers as determined by the k-means estimator:

# In[103]:


# Visualising the clusters - On the first two columns
plt.scatter(iris_ind[y_kmeans == 0, 0], x[y_kmeans == 0, 1], 
            s = 100, c = 'red', label = 'Iris-setosa')
plt.scatter(x[y_kmeans == 1, 0], x[y_kmeans == 1, 1], 
            s = 100, c = 'blue', label = 'Iris-versicolour')
plt.scatter(x[y_kmeans == 2, 0], x[y_kmeans == 2, 1],
            s = 100, c = 'green', label = 'Iris-virginica')

# Plotting the centroids of the clusters
plt.scatter(k[:, 0], k[:,1], 
            s = 100, c = 'yellow', label = 'Centroids')

plt.legend();

